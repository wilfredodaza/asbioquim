$(document).ready(function () {
    $('.slider.fullscreen').slider({
        full_width: true
    });
});